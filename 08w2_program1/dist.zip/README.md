## To Compile and run the Program
```bash
make
make run
```