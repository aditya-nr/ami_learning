void _swapChar(char *p1,char *p2){
    char tmp=*p1;
    *p1=*p2;
    *p2=tmp;
}