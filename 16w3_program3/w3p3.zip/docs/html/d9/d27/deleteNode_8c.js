var deleteNode_8c =
[
    [ "delete", "d9/d27/deleteNode_8c.html#ab7ffb3ee4ffb3a43f2e9d0239d9cfd41", null ]
];