var structtree =
[
    [ "data", "dc/d20/structtree.html#ac5fb85480ddf2f373b099c2a2df0edab", null ],
    [ "left", "dc/d20/structtree.html#a719b6f34a3ac12d46c29f9b7d6308438", null ],
    [ "right", "dc/d20/structtree.html#aaab740c920c9c2c403df5a9245af5166", null ]
];