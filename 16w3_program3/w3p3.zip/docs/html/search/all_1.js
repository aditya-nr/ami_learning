var searchData=
[
  ['data_0',['data',['../dc/d20/structtree.html#ac5fb85480ddf2f373b099c2a2df0edab',1,'tree']]],
  ['delete_1',['delete',['../d9/d27/deleteNode_8c.html#ab7ffb3ee4ffb3a43f2e9d0239d9cfd41',1,'delete(tree_t **tree, int value):&#160;deleteNode.c'],['../d3/d09/tree_8h.html#ab7ffb3ee4ffb3a43f2e9d0239d9cfd41',1,'delete(tree_t **tree, int value):&#160;deleteNode.c']]],
  ['deletenode_2ec_2',['deleteNode.c',['../d9/d27/deleteNode_8c.html',1,'']]]
];
