var searchData=
[
  ['delete_0',['delete',['../d9/d27/deleteNode_8c.html#ab7ffb3ee4ffb3a43f2e9d0239d9cfd41',1,'delete(tree_t **tree, int value):&#160;deleteNode.c'],['../d3/d09/tree_8h.html#ab7ffb3ee4ffb3a43f2e9d0239d9cfd41',1,'delete(tree_t **tree, int value):&#160;deleteNode.c']]]
];
