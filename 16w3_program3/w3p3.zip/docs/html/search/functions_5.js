var searchData=
[
  ['search_0',['search',['../d1/d2e/searchNode_8c.html#a3bd3e16895ae76136a15df92f487429d',1,'search(tree_t *tree, int value):&#160;searchNode.c'],['../d3/d09/tree_8h.html#a3bd3e16895ae76136a15df92f487429d',1,'search(tree_t *tree, int value):&#160;searchNode.c']]]
];
