var searchData=
[
  ['data_0',['data',['../dc/d20/structtree.html#ac5fb85480ddf2f373b099c2a2df0edab',1,'tree']]]
];
