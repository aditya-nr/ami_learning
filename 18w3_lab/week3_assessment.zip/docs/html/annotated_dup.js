var annotated_dup =
[
    [ "customer", "de/dfb/structcustomer.html", "de/dfb/structcustomer" ],
    [ "denominations", "d6/d07/structdenominations.html", "d6/d07/structdenominations" ]
];