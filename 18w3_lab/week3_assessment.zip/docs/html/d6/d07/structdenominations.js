var structdenominations =
[
    [ "_100", "d6/d07/structdenominations.html#a121d67aad56e11baa485115a143e6119", null ],
    [ "_200", "d6/d07/structdenominations.html#afeea338c6e407f15711e66642866161c", null ],
    [ "_50", "d6/d07/structdenominations.html#a2ab564a0f3f4ba851827ea5edb09fa28", null ],
    [ "_500", "d6/d07/structdenominations.html#a299ceb1c07fb384330275d1e8d2e34fc", null ],
    [ "total_money", "d6/d07/structdenominations.html#a2136c7c4c69b6017132be69c04aa05c0", null ]
];