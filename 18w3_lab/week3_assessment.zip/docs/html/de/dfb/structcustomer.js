var structcustomer =
[
    [ "balance", "de/dfb/structcustomer.html#a426796667acb985ec6f6d3817aa08cd4", null ]
];