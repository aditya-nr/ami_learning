var searchData=
[
  ['compile_0',['Compile',['../d0/d30/md_README.html#autotoc_md1',1,'']]],
  ['customer_1',['customer',['../de/dfb/structcustomer.html',1,'']]],
  ['customer_5ft_2',['customer_t',['../d4/dbf/main_8h.html#adbf6c0a93e57785ef3c8866e43726d93',1,'main.h']]]
];
