var searchData=
[
  ['balance_0',['balance',['../de/dfb/structcustomer.html#a426796667acb985ec6f6d3817aa08cd4',1,'customer']]]
];
